/**
 * MySubmarine
 * @constructor
 */
 function MySubmarine(scene) {
 	CGFobject.call(this,scene);
	
 	this.submarineRotation = 125 * degToRad;
	this.submarineX = 5;
	this.submarineY = 0;
	this.submarineZ = 0;

 	this.initBuffers();
 };

 MySubmarine.prototype = Object.create(CGFobject.prototype);
 MySubmarine.prototype.constructor = MySubmarine;

 MySubmarine.prototype.initBuffers = function() {
 	
 	this.vertices = [
 		0.5 , 0.3 , 0,
 		-0.5 , 0.3 , 0,
 		0 , 0.3 , 2 
 	];

 	this.normals = [
 		0, 0, 1,
 		0, 0, 1,
 		0, 0, 1
 	];
 	 	
 	this.indices = [
 		0, 1, 2
 	];


 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
}

MySubmarine.prototype.move = function (input) { 
	switch(input){
		case ("up"):
		{
			this.submarineX += Math.sin(this.submarineRotation);
			this.submarineZ += Math.cos(this.submarineRotation);
			break;
		}
		case("down"):
		{
			this.submarineX -= Math.sin(this.submarineRotation);
			this.submarineZ -= Math.cos(this.submarineRotation);
			break;
		}
		case("left"):
		{
			this.submarineRotation += 5 * degToRad;
			break;
		}
		case("right"):
		{
			this.submarineRotation -= 5 * degToRad;
			break;
		}
	}


	if(this.submarineRotation >= (Math.PI*2)){ //Previne overflow
		this.submarineRotation -= Math.PI*2;
	}else if(this.submarineRotation <= -(Math.PI*2)){
		this.submarineRotation += Math.PI*2;
	}
		
};

MySubmarine.prototype.customDisplay = function () { 

	this.scene.pushMatrix();
		this.scene.translate(this.submarineX,this.submarineY,this.submarineZ);
		this.scene.rotate(this.submarineRotation, 0, 1, 0); 
		this.display();
	this.scene.popMatrix();
		
};


